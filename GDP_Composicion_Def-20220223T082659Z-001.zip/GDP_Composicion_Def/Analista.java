package GDP_Composicion;

public class Analista extends Empleado{

	public Analista() {
		super();
	}
	
}
