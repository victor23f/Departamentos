package GDP_Composicion;

public class Departamento {

	private String nombre, localizacion;
	private Empleado[] listaEmpleados;
	private int dept_no;

	public Departamento() {

	}

	public Departamento(int dept_no, String nombre, String localizacion,
			Empleado[] listaEmpleados) {

		this.dept_no = dept_no;
		this.nombre = nombre;
		this.localizacion = localizacion;
		this.listaEmpleados = new Empleado[5];
		this.listaEmpleados = listaEmpleados;

	}

	public String getNombre() {
		return nombre;
	}

	public void mostrarEmpleados() {
		for (int i = 0; i < listaEmpleados.length; i++) {
			if (listaEmpleados[i] == null) {

			} else {
				System.out.println(listaEmpleados[i]);
			}

		}

	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getLocalizacion() {
		return localizacion;
	}

	public void setLocalizacion(String localizacion) {
		this.localizacion = localizacion;
	}

	public int getDept_no() {
		return dept_no;
	}

	public void setDept_no(int dept_no) {
		this.dept_no = dept_no;
	}

	@Override
	public String toString() {
		return " [Nombre: " + getNombre() + " |Localizacion: "
				+ getLocalizacion() + " |Numero de departamento: "
				+ getDept_no();
	}

	public Empleado[] getListaEmpleados() {
		return listaEmpleados;
	}

	public void setListaEmpleados(Empleado[] listaEmpleados) {
		this.listaEmpleados = listaEmpleados;
	}
	public int posicionEmpleado(int numeroEmpleado) {
		int n = this.listaEmpleados.length;
		int centro;
		int inf=0;
		int sup=n-1;
		
		
		while(inf<=sup){
		     centro=(sup+inf)/2;
		     if(this.listaEmpleados[centro].getNumeroEmpleado()==numeroEmpleado) return centro;
		     else if(numeroEmpleado < this.listaEmpleados[centro].getNumeroEmpleado() ){
		        sup=centro-1;
		     }else if (this.listaEmpleados[inf].getNumeroEmpleado() == numeroEmpleado) {
					return inf;
			}
		     else {
		       inf=centro+1;
		     } 
		     
		     
		   }
		   return -1;

	}
	
	
}
	/*
	 * for (int i = 0; i < this.listaEmpleados.length; i++) { if
	 * (this.listaEmpleados[i] != null) { if (this.listaEmpleados[i]
	 * .getNumeroEmpleado() == numeroEmpleado) { posicion = i; } } }
	 */