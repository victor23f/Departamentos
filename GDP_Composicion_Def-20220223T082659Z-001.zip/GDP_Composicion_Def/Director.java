package GDP_Composicion;

public class Director extends Empleado{

	private double comision;
	
	public Director() {
		super();
	}
	public Director(double comision) {
		this.comision=comision;
	}
	
}
