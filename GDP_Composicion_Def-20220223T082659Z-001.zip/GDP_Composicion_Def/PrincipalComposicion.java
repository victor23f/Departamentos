package GDP_Composicion;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.time.LocalDate;

public class PrincipalComposicion {

	static BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
	static Departamento listaDepartamentos[] = new Departamento[5];
	static Empleado[] listaEmpleados = new Empleado[3];

	public static void main(String[] args) {
		/*
		 * for (Empleado empleado : listaEmpleados) {
		 * empleado.setDepartamento(listaDepartamentos[0]); }
		 */
		for (int i = 0; i < listaDepartamentos.length; i++) {

			listaDepartamentos[i] = new Departamento();
		}
		listaDepartamentos[0] = new Departamento(1, "Administracion", "Vva", listaEmpleados);

		listaDepartamentos[2] = new Departamento(3, "Ventas", "Vva", listaEmpleados);

		/*
		 * System.out.println(MayorSalario()); listaDepartamentos[0].mostrarEmpleados();
		 * System.out.println(
		 * "Este numero de departamento se encuentra en la posicion " +
		 * posicionDepartamento(2) + " del array"); //
		 * System.out.println(posicionEmpleado(10)); System.out
		 * .println("Este numero de empleado se encuentra en la posicion " +
		 * listaDepartamentos[0].posicionEmpleado(10) + " del array");
		 * System.out.println(posicionEmpleado(40, listaEmpleados));
		 */
		menuPrincipal();

	}

	public static String MayorSalario() {
		String nombre = "";
		double mayor = 0;

		for (int i = 0; i < listaDepartamentos.length; i++) {
			if (listaDepartamentos[i] != null) {
				for (int j = 0; j < listaDepartamentos[i].getListaEmpleados().length; j++) {
					if (listaDepartamentos[i] == null || listaDepartamentos[i].getListaEmpleados()[j] == null) {
						break;
					} else if (listaDepartamentos[i].getListaEmpleados()[j].getSalario() > mayor) {
						mayor = listaDepartamentos[i].getListaEmpleados()[j].getSalario();
						nombre = listaDepartamentos[i].getListaEmpleados()[j].getApellido();
					}

				}
			}

		}

		return nombre;
	}

	public static int posicionDepartamento(int dept_no) {
		int posicion = 0;
		try {

			for (int i = 0; i < listaDepartamentos.length; i++) {
				if (listaDepartamentos[i] != null) {
					if (listaDepartamentos[i].getDept_no() == dept_no) {
						posicion = i;
					}
				}
			}

		} catch (Exception e) {
		}
		return posicion;

	}

	public static int posicionEmpleado(int numeroEmpleado, Empleado[] lista) {
		int n = lista.length;
		int centro;
		int inf = 0;
		int sup = n - 1;
		try {

			while (inf <= sup) {
				centro = (sup + inf) / 2;
				if (lista[centro].getNumeroEmpleado() == numeroEmpleado)
					return centro + 1;
				else if (numeroEmpleado < lista[centro].getNumeroEmpleado()) {
					sup = centro - 1;
				} else if (lista[inf].getNumeroEmpleado() == numeroEmpleado) {
					return inf + 1;
				} else {
					inf = centro + 1;
				}

			}
		} catch (NullPointerException e) {
			System.err.println("Error, el numero de empleado introducido no existe, prueba con otro");

		}

		catch (Exception e) {

		}
		return -1;

	}

	public static void menuPrincipal() {
		boolean salir = false;
		do {

			System.out.println("---------------Menu---------------");
			System.out.println("�Con qu� quieres trabajar?");
			System.out.println("1- Departamentos");
			System.out.println("2- Empleados");
			System.out.println("3- Salir");
			try {
				int opcion = Integer.parseInt(teclado.readLine());
				switch (opcion) {
				case 1:
					menuDepartamento();
					break;
				case 2:
					menuEmpleados();
					break;
				case 3:
					System.out.println("�Adios!");
					salir = true;
				default:
					break;
				}
			} catch (NumberFormatException e) {
				System.err.println("Debes de introducir un numero");
			} catch (Exception e) {

			}
		} while (!salir);
	}

	public static void menuEmpleados() {

		int opcionmenu = 0;
		do {

			try {
				System.out.println("     MENU EMPLEADOS ");
				System.out.println("========================");
				System.out.println("1-Carga de datos");
				System.out.println("2-Empleado mas veterano");
				System.out.println("3-Mostrar empleados");
				System.out.println("4-Borrar empleado");
				System.out.println("5-Comprobar espacio");
				System.out.println("6-Mostrar posicion de un empleado en el array a partir de su id");
				System.out.println("7-Volver");
				System.out.println("========================");
				opcionmenu = Integer.parseInt(teclado.readLine());
				switch (opcionmenu) {
				case 1:
					elegirCargaDeDatosEmpleado();
					break;

				case 2:
					System.out.println("El empleado mas veterano se encuentra en la posicion: " + masVeterano()
							+ " y su nombre es: " + listaEmpleados[masVeterano()].getApellido());
					break;
				case 3:
					mostrarEmpleados();
					break;
				case 4:
					borrarEmpleado();
					break;
				case 5:
					if (llenoEmpleados()) {
						System.out.println("La lista de empleados est� llena");
					}else if (vacioEmpleados()) {
						System.out.println("La lista de empleados est� vacia");
					}else {
						System.out.println("La lista de empleados no est� llena");
					}
					break;
				case 6:
					System.out.println("Introduce el numero del empleado:");
					int numeroEmp = Integer.parseInt(teclado.readLine());
					if (posicionEmpleado(numeroEmp, listaEmpleados) != -1) {
						System.out.println("El empleado se encuentra en la posicion: "
								+ posicionEmpleado(numeroEmp, listaEmpleados));
					}
					break;
				case 7:
					break;
				default:
					System.out.println("Elija una de las opciones validas");
					break;
				}
			} catch (NumberFormatException e) {
				System.err.println("Solo se permiten numeros");
			} catch (Exception e) {

			}
		} while (opcionmenu != 7);
	}

	public static void elegirCargaDeDatosEmpleado() {
		int opcion = 0;
		boolean salir = false;
		while (!salir) {
			try {
				System.out.println("\n�Qu� tipo de carga de datos desea realizar? \n");
				System.out.println("1- Carga interactiva");
				System.out.println("2- Carga automatica");
				opcion = Integer.parseInt(teclado.readLine());

				switch (opcion) {
				case 1:
					cargaInteractiva();
					mostrarEmpleados();
					salir = true;
					break;
				case 2:
					cargaAutomatica();
					mostrarEmpleados();
					salir = true;
					break;
				default:
					salir = false;
					break;
				}
			} catch (NumberFormatException e) {
				System.err.println("Debes de introducir un numero");
			} catch (Exception e) {

			}
		}

	}

	public static int masVeterano() { // devuelve la posicion del array en la
										// que se encuentra el empleado mas
										// veterano
		int posicion = 0;
		for (int i = 0; i < listaEmpleados.length; i++) {
			if (listaEmpleados[i] != null) {

				if (listaEmpleados[posicion].getFecha().isAfter(listaEmpleados[i].getFecha())) {
					posicion = i;
				}
			}
		}
		return posicion;
	}

	public static void cargaInteractiva() {
		int id = 0;
		String apellido = null;
		String oficio = null;
		double salario = 0;
		int numerodepartamento = 0;
		LocalDate fecha = null;
		String seguir = "no";

		do {

			if (!llenoEmpleados()) {
				
			
			try {
				System.out.println("Introduce el ID:");
				id = Integer.parseInt(teclado.readLine());
				System.out.println("Introduce el apellido:");
				apellido = teclado.readLine();
				System.out.println("Introduce el oficio:");
				oficio = teclado.readLine();
				System.out.println("Introduce el salario:");
				salario = Double.parseDouble(teclado.readLine());
				System.out.println("Introduce el numero de departamento:");
				numerodepartamento = Integer.parseInt(teclado.readLine());
				System.out.println("Introduce la fecha de alta(Y-M-D):");
				fecha = LocalDate.parse(teclado.readLine());

			} catch (Exception e) {

			}
			for (int i = 0; i < listaEmpleados.length; i++) {

				if (listaEmpleados[i] == null) {
					listaEmpleados[i] = new Empleado(id, apellido, oficio, salario,
							listaDepartamentos[numerodepartamento - 1].getDept_no(), fecha);
					break;
				}

			}
			try {
				System.out.println("�Quieres seguir a�adiendo empleados?(si/no)");
				seguir = teclado.readLine();
			} catch (Exception e) {
			}
			}else {
				System.err.println("La lista de empleados est� llena");
				seguir="no";
			}
		} while (!seguir.equals("no"));

	}

	public static void cargaInteractivaDepartamentos() {

		boolean salir = false;

		do {

			try {

				if (llenoEmpleados()) {
					System.err.println("El array est� lleno, no puedes introducir mas departamentos");
					System.out.println("Estos son los datos del array:");
					mostrarDepartamentos();
					salir = true;
				} else if (!llenoEmpleados()) {
					for (int i = 0; i < listaDepartamentos.length; i++) {
						if (listaDepartamentos[i].getNombre() == null) {

							System.out.println("Introduce el nombre del departamento n�" + (i + 1));
							String nombreInteractivo = teclado.readLine();
							System.out.println("Introduce la localizacion del departamento n�" + (i + 1));
							String LocalizacionInteractiva = teclado.readLine();
							System.out.println("Introduce el numero del departamento n�" + (i + 1));
							int noInteractivo = Integer.parseInt(teclado.readLine());
							System.out.println(
									"Introduce el numero de la lista del empleado que deseas agregar al departamento");
							int noListaEmpleado = Integer.parseInt(teclado.readLine());
							listaDepartamentos[i] = new Departamento(noInteractivo, nombreInteractivo,
									LocalizacionInteractiva, listaEmpleados[noListaEmpleado - 1].getListaEmpleados());

							break;

						}

					}
					salir = true;
				}
				{

				}

			} catch (Exception e) {
				System.err.println("No se han encontrado empleados disponibles");
				salir =true;
			}
		} while (salir == false);

	}

	public static void mostrarEmpleados() { // listado autom�tico
		int contador = 0;

		for (int i = 0; i < listaEmpleados.length; i++) {
			if (listaEmpleados[i] != null) {
				System.out.println(listaEmpleados[i]);
				contador++;
			}

		}

		System.out.println("Hay " + contador + " empleados.");
	}

	public static void cargaAutomatica() {

		listaEmpleados[0] = new Empleado(10, "Luis", "java developer", 2600, listaDepartamentos[0].getDept_no(),
				LocalDate.of(1980, 4, 10));
		listaEmpleados[1] = new Empleado(20, "Maria", "programadora", 3000, listaDepartamentos[0].getDept_no(),
				LocalDate.of(1970, 4, 10));
		listaEmpleados[2] = new Empleado(30, "Jose", "Python", 4000, listaDepartamentos[0].getDept_no(),
				LocalDate.of(1980, 4, 10));
		/*
		 * listaEmpleados[0] = new Empleado(3, "G�mez", "Programador", 3000, 20, 1,
		 * LocalDate.of(2020, 11, 26)); listaEmpleados[1] = new Empleado(5, "P�rez",
		 * "Analista", 3600, 2, 2, LocalDate.of(2021, 11, 26)); listaEmpleados[2] = new
		 * Empleado(7, "Fern�ndez", "Analista", 2800, 2, 2, LocalDate.of(2010, 11, 26));
		 * listaEmpleados[3] = new Empleado(6, "Segovia", "Desarrolador Web", 3100, 2,
		 * 2, LocalDate.of(2021, 11, 26)); listaEmpleados[4] = new Empleado(2,
		 * "S�nchez", "Dise�ador Gr�fico", 2500, 2, 2, LocalDate.of(2021,11, 26));
		 */
	}

	public static void borrarEmpleado() {

		try {

			System.out.println("Introduce el id del empleado que quieras borrar");
			int borrarId = Integer.parseInt(teclado.readLine());
			for (int i = 0; i < listaEmpleados.length; i++) {
				if (listaEmpleados[i].getNumeroEmpleado() == borrarId) {
					listaEmpleados[i] = null;
					for (int j = 0; j < listaEmpleados.length; j++) {
						listaEmpleados[j] = listaEmpleados[j - 1];
					}
				}
			}
		} catch (Exception e) {

		}

	}

	public static void menuDepartamento() {
		boolean acabar = false;
		do {
			mostrarDepartamentos();
			System.out.println("  MENU DEPARTAMENTOS");
			System.out.println("========================");
			System.out.println("1 - Mostrar un departamento a partir de su dept_no. \r\n" + "\r\n"
					+ "2 - Insertar un departamento interactivo.\r\n" + "\r\n"
					+ "3 - Borrar un departamento a partir de su dept_no.\r\n" + "\r\n"
					+ "4 - Modificar atributo de departamentos a partir de su dept_no.\r\n" + "\r\n" + "5 - Volver.");
			System.out.println("========================");

			try {

				int opcion = Integer.parseInt(teclado.readLine());
				switch (opcion) {
				case 1:
					mostrarDep();

					break;

				case 2:

					cargaInteractivaDepartamentos();
				default:
					break;
				case 3:
					borrarDep();
					break;
				case 4:
					modificarAtributos();
					break;

				case 5:
					acabar = true;
					break;
				}
			} catch (Exception e) {

			}
		} while (acabar == false);
	}

	public static void mostrarDep() {
		try {
			System.out.println("Introduzca el numero de departamento para ver sus datos");
			int dept_no = Integer.parseInt(teclado.readLine());
			for (int i = 0; i < listaDepartamentos.length; i++) {
				if (listaDepartamentos[i] != null) {
					if (listaDepartamentos[i].getDept_no() == dept_no) {
						System.out.println(listaDepartamentos[i]);
					}
				}
			}
		} catch (Exception e) {
		}
	}

	public static void borrarDep() {
		try {
			System.out.println("Introduzca el numero de departamento para borrar sus datos:");
			int dept_no = Integer.parseInt(teclado.readLine());
			for (int i = 0; i < listaDepartamentos.length; i++) {
				if (listaDepartamentos[i].getDept_no() == dept_no) {
					listaDepartamentos[i] = null;
				}
			}
		} catch (Exception e) {

		}
	}

	public static void modificarAtributos() {

		try {
			System.out.println("Introduce el numero de departamento para modificar sus datos:");
			int dept_no = Integer.parseInt(teclado.readLine());
			for (int i = 0; i < listaDepartamentos.length; i++) {

				if (listaDepartamentos[i].getDept_no() == dept_no) {
					System.out.println("�Q�e datos deseas cambiar?");
					System.out.println("1-Numero de departamento");
					System.out.println("2-Nombre de departamento");
					System.out.println("3-Localizaci�n de departamento");
					int datoAcambiar = Integer.parseInt(teclado.readLine());

					switch (datoAcambiar) {
					case 1:
						System.out.println("Introduce el nuevo numero de departamento:");
						int nuevoDept_no = Integer.parseInt(teclado.readLine());
						listaDepartamentos[i].setDept_no(nuevoDept_no);

						break;
					case 2:
						System.out.println("Introduce el nuevo nombre de departamento:");
						String nuevoDept = teclado.readLine();
						listaDepartamentos[i].setNombre(nuevoDept);

						break;
					case 3:
						System.out.println("Introduce la nueva localizacion de departamento:");
						String nuevaLocalizacion = teclado.readLine();
						listaDepartamentos[i].setLocalizacion(nuevaLocalizacion);

						break;
					default:
						break;
					}
				}

			}
		} catch (NullPointerException e) {

		} catch (Exception e) {

		}

	}

	public static boolean llenoEmpleados() {
		boolean bandera = false;
		boolean control = false;// creamos variable para controlar los espacios vacios del array
		for (int i = 0; i < listaEmpleados.length; i++) {
			if (listaEmpleados[i] == null) {
				bandera = false;
				control = true;
			} else {
				bandera = true;
			}

		}
		if (control) {
			bandera = false;
		}

		return bandera;

	}

	public static void mostrarDepartamentos() {
		for (int i = 0; i < listaDepartamentos.length; i++) {
			if (listaDepartamentos[i].getNombre() != null) {//preguntar a saul (getNombre || posicion)
				System.out.println(listaDepartamentos[i]);
			}

		}
	}
	public static boolean vacioEmpleados(){
		boolean bandera = true;
		for (int i = 0; i < listaEmpleados.length; i++) {
			if (listaEmpleados[i] != null) {
				bandera=false;
			}
		}
		return bandera;
	}
}